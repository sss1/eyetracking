import glob
import csv
import matplotlib.pyplot as plt

quality_list = []
quality_list_either = []

for files in (set(glob.glob("*.csv"))): #- set(glob.glob("**"))):
    participant = open(files, 'rb')
    reader = list(csv.reader(participant))

    count = 0
    valid = 0
    valid_either = 0

    for row in reader:
        if not "0.0" in row:
            valid += 1
        if not "0.0" in row[1:3] or not "0.0" in row[3:5]:
            valid_either += 1
        count += 1

    average = (float(valid))/float(count)
    average_either = (float(valid_either))/float(count)
    print average
    quality_list.append(average)
    quality_list_either.append(average_either)

total_average = sum(quality_list)/float(len(quality_list))
total_average_either = sum(quality_list_either)/float(len(quality_list_either))
print [total_average, total_average_either] 

plt.hist(quality_list, 20)
plt.show()

plt.hist(quality_list_either, 20)
plt.show()
